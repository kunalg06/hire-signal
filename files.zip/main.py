from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
import secrets
import uuid
import sqlite3
import docker
import subprocess
import json
from datetime import datetime
from pathlib import Path
import anthropic

# ============================================================================
# Initialize FastAPI App & Docker Client
# ============================================================================

app = FastAPI(title="Claude Assignment Platform")
docker_client = docker.from_env()
anthropic_client = anthropic.Anthropic()  # Uses ANTHROPIC_API_KEY env var

# Database setup
DB_PATH = "assignments.db"

def init_db():
    """Initialize SQLite database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Create assignments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS assignments (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            starter_code TEXT,
            evaluation_criteria TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create session links table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS session_links (
            link_id TEXT PRIMARY KEY,
            assignment_id TEXT NOT NULL,
            container_id TEXT,
            port INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            FOREIGN KEY(assignment_id) REFERENCES assignments(id)
        )
    ''')
    
    # Create submissions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS submissions (
            submission_id TEXT PRIMARY KEY,
            link_id TEXT NOT NULL,
            assignment_id TEXT NOT NULL,
            code TEXT,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            evaluation_result TEXT,
            score REAL,
            feedback TEXT,
            FOREIGN KEY(link_id) REFERENCES session_links(link_id),
            FOREIGN KEY(assignment_id) REFERENCES assignments(id)
        )
    ''')
    
    conn.commit()
    conn.close()

init_db()

# ============================================================================
# Data Models
# ============================================================================

class Assignment(BaseModel):
    title: str
    description: str
    starter_code: Optional[str] = None
    evaluation_criteria: str

class AssignmentResponse(Assignment):
    id: str

class LinkResponse(BaseModel):
    link_id: str
    assignment_id: str
    access_url: str
    vscode_port: int
    expires_at: str

class CodeSubmission(BaseModel):
    code: str

class EvaluationResult(BaseModel):
    submission_id: str
    score: float
    feedback: str
    evaluation_details: dict

# ============================================================================
# Assignment Management
# ============================================================================

@app.post("/api/assignments", response_model=AssignmentResponse)
async def create_assignment(assignment: Assignment):
    """Create a new coding assignment"""
    assignment_id = str(uuid.uuid4())
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO assignments (id, title, description, starter_code, evaluation_criteria)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        assignment_id,
        assignment.title,
        assignment.description,
        assignment.starter_code,
        assignment.evaluation_criteria
    ))
    
    conn.commit()
    conn.close()
    
    return AssignmentResponse(
        id=assignment_id,
        title=assignment.title,
        description=assignment.description,
        starter_code=assignment.starter_code,
        evaluation_criteria=assignment.evaluation_criteria
    )

@app.get("/api/assignments/{assignment_id}", response_model=AssignmentResponse)
async def get_assignment(assignment_id: str):
    """Retrieve assignment details"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute(
        "SELECT id, title, description, starter_code, evaluation_criteria FROM assignments WHERE id = ?",
        (assignment_id,)
    )
    row = cursor.fetchone()
    conn.close()
    
    if not row:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    return AssignmentResponse(
        id=row[0],
        title=row[1],
        description=row[2],
        starter_code=row[3],
        evaluation_criteria=row[4]
    )

# ============================================================================
# Docker Management
# ============================================================================

def find_available_port(start_port=6000):
    """Find an available port for VS Code"""
    import socket
    for port in range(start_port, start_port + 1000):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(('127.0.0.1', port))
            sock.close()
            return port
        except OSError:
            continue
    raise RuntimeError("No available ports found")

def start_docker_container(assignment_id: str, starter_code: Optional[str] = None) -> tuple[str, int]:
    """
    Start a Docker container with code-server and Claude CLI
    Returns: (container_id, port)
    """
    port = find_available_port()
    
    # Container environment
    environment = {
        'CODE_SERVER_AUTH': 'none',  # For demo; use auth in production
        'ANTHROPIC_API_KEY': '',  # Will be passed at runtime
    }
    
    # Mount volume for persistent code
    volumes = {
        f'/tmp/assignment_{assignment_id}': {'bind': '/workspace', 'mode': 'rw'}
    }
    
    # Create initial code file if starter code provided
    code_dir = Path(f'/tmp/assignment_{assignment_id}')
    code_dir.mkdir(parents=True, exist_ok=True)
    
    if starter_code:
        (code_dir / 'solution.py').write_text(starter_code)
    else:
        (code_dir / 'solution.py').write_text('# Write your solution here\n')
    
    try:
        container = docker_client.containers.run(
            'codercom/code-server:latest',
            command=['--bind', f'0.0.0.0:{port}', '--auth', 'none'],
            ports={f'{port}/tcp': port},
            volumes=volumes,
            environment=environment,
            detach=True,
            name=f'assignment_{assignment_id}_{uuid.uuid4().hex[:8]}',
            remove=False
        )
        return container.id, port
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start container: {str(e)}")

# ============================================================================
# Link Generation & Session Management
# ============================================================================

@app.post("/api/generate-link/{assignment_id}", response_model=LinkResponse)
async def generate_link(assignment_id: str):
    """Generate a unique link for accessing the coding environment"""
    
    # Verify assignment exists
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT starter_code FROM assignments WHERE id = ?", (assignment_id,))
    result = cursor.fetchone()
    
    if not result:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    starter_code = result[0]
    conn.close()
    
    # Start Docker container
    container_id, port = start_docker_container(assignment_id, starter_code)
    
    # Generate unique link
    link_id = secrets.token_urlsafe(32)
    
    # Store in database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO session_links (link_id, assignment_id, container_id, port)
        VALUES (?, ?, ?, ?)
    ''', (link_id, assignment_id, container_id, port))
    
    conn.commit()
    conn.close()
    
    return LinkResponse(
        link_id=link_id,
        assignment_id=assignment_id,
        access_url=f"http://localhost:{port}",
        vscode_port=port,
        expires_at=(datetime.now().isoformat())
    )

@app.get("/api/session/{link_id}")
async def get_session_info(link_id: str):
    """Get session and container information"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT assignment_id, container_id, port FROM session_links WHERE link_id = ?
    ''', (link_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if not row:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {
        "link_id": link_id,
        "assignment_id": row[0],
        "container_id": row[1],
        "vscode_url": f"http://localhost:{row[2]}"
    }

# ============================================================================
# Submission & Evaluation
# ============================================================================

def evaluate_code_with_claude(code: str, assignment: AssignmentResponse) -> EvaluationResult:
    """
    Evaluate submitted code using Claude API
    """
    submission_id = str(uuid.uuid4())
    
    evaluation_prompt = f"""
You are an expert code reviewer and educator. Evaluate the following student submission.

ASSIGNMENT:
Title: {assignment.title}
Description: {assignment.description}

EVALUATION CRITERIA:
{assignment.evaluation_criteria}

SUBMITTED CODE:
```python
{code}
```

Provide a structured evaluation including:
1. Correctness (does it solve the problem?)
2. Code quality (readability, efficiency, best practices)
3. Completeness (does it cover all requirements?)
4. Score: Rate from 0-100

Format your response as JSON with keys: correctness, code_quality, completeness, overall_feedback, score
"""
    
    try:
        message = anthropic_client.messages.create(
            model="claude-opus-4-1",
            max_tokens=1024,
            messages=[
                {"role": "user", "content": evaluation_prompt}
            ]
        )
        
        response_text = message.content[0].text
        
        # Parse JSON from response
        import re
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        
        if json_match:
            eval_data = json.loads(json_match.group())
        else:
            eval_data = {
                "correctness": "Unable to parse",
                "code_quality": "Unable to parse",
                "completeness": "Unable to parse",
                "overall_feedback": response_text,
                "score": 0
            }
        
        return EvaluationResult(
            submission_id=submission_id,
            score=eval_data.get('score', 0),
            feedback=eval_data.get('overall_feedback', ''),
            evaluation_details=eval_data
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Evaluation failed: {str(e)}")

@app.post("/api/submit/{link_id}", response_model=EvaluationResult)
async def submit_assignment(link_id: str, submission: CodeSubmission, background_tasks: BackgroundTasks):
    """Submit code for evaluation"""
    
    # Get session and assignment info
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT assignment_id, container_id FROM session_links WHERE link_id = ?
    ''', (link_id,))
    session = cursor.fetchone()
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    assignment_id, container_id = session
    
    # Get assignment details
    cursor.execute('''
        SELECT title, description, evaluation_criteria FROM assignments WHERE id = ?
    ''', (assignment_id,))
    assignment_row = cursor.fetchone()
    
    if not assignment_row:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    assignment = AssignmentResponse(
        id=assignment_id,
        title=assignment_row[0],
        description=assignment_row[1],
        evaluation_criteria=assignment_row[3]
    )
    
    # Evaluate code
    evaluation = evaluate_code_with_claude(submission.code, assignment)
    
    # Store submission
    submission_id = evaluation.submission_id
    cursor.execute('''
        INSERT INTO submissions (submission_id, link_id, assignment_id, code, evaluation_result, score, feedback)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        submission_id,
        link_id,
        assignment_id,
        submission.code,
        json.dumps(evaluation.evaluation_details),
        evaluation.score,
        evaluation.feedback
    ))
    
    conn.commit()
    conn.close()
    
    # Clean up container in background
    background_tasks.add_task(cleanup_container, container_id)
    
    return evaluation

def cleanup_container(container_id: str):
    """Stop and remove container"""
    try:
        container = docker_client.containers.get(container_id)
        container.stop()
        container.remove()
    except Exception as e:
        print(f"Error cleaning up container {container_id}: {e}")

@app.get("/api/submission/{submission_id}")
async def get_submission(submission_id: str):
    """Retrieve submission and evaluation results"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT submission_id, link_id, assignment_id, code, submitted_at, evaluation_result, score, feedback
        FROM submissions WHERE submission_id = ?
    ''', (submission_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if not row:
        raise HTTPException(status_code=404, detail="Submission not found")
    
    return {
        "submission_id": row[0],
        "link_id": row[1],
        "assignment_id": row[2],
        "code": row[3],
        "submitted_at": row[4],
        "evaluation_result": json.loads(row[5]) if row[5] else None,
        "score": row[6],
        "feedback": row[7]
    }

# ============================================================================
# Health & Info Endpoints
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "ok", "service": "Claude Assignment Platform"}

@app.get("/")
async def root():
    """API documentation"""
    return {
        "service": "Claude Assignment Platform",
        "endpoints": {
            "assignments": {
                "POST /api/assignments": "Create new assignment",
                "GET /api/assignments/{id}": "Get assignment details"
            },
            "links": {
                "POST /api/generate-link/{assignment_id}": "Generate access link",
                "GET /api/session/{link_id}": "Get session info"
            },
            "submissions": {
                "POST /api/submit/{link_id}": "Submit code for evaluation",
                "GET /api/submission/{submission_id}": "Get submission results"
            }
        }
    }

# ============================================================================
# Run server
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
